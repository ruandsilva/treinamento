package com.indracompany.treinamento.model.dto;

public class GenericDTO {

}

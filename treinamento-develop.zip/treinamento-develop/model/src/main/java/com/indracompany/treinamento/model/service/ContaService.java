package com.indracompany.treinamento.model.service;

import java.util.List;

public class ContaService {

	public List<String> obterContas(String cpf) {
		// TODO Auto-generated method stub
		return null;
	}

}
